import SwiftUI

struct RootView: View {
    @StateObject private var router = Router.shared
    @StateObject private var config = AppConfig.shared
    @State private var ready = false

    var body: some View {
        Group {
            if !ready {
                Splash()
            } else {
                ZStack(alignment: .bottom) {
                    NavigationStack(path: $router.path) {
                        tabContent
                            .toolbar(.hidden, for: .navigationBar)
                            .navigationDestination(for: Route.self) { route in
                                destination(route)
                                    .toolbar(.hidden, for: .navigationBar)
                            }
                    }
                    if router.path.isEmpty {
                        FloatingTabBar(selected: router.tab) { router.goTab($0) }
                    }
                }
                .background(config.background)
            }
        }
        .environmentObject(router)
        .environmentObject(config)
        .tint(config.primary)
        .task {
            await config.load()
            ready = true
        }
    }

    @ViewBuilder private var tabContent: some View {
        Group {
            switch router.tab {
            case 1: KesfetView()
            case 2: AnnouncementsView(isTab: true)
            case 3: MenuView()
            default: HomeView()
            }
        }
        // Kayan alt menünün altında içerik kalmasın
        .safeAreaInset(edge: .bottom) { Color.clear.frame(height: 84) }
    }

    @ViewBuilder private func destination(_ r: Route) -> some View {
        switch r {
        case .place(let id): PlaceDetailView(id: id)
        case .page(let slug): PageView(slug: slug)
        case .events: EventsView()
        case .obituaries: ObituariesView()
        case .projects: ProjectsView()
        case .contact: ContactView()
        }
    }
}

/// Tasarımdaki kayan koyu alt menü: seçili sekme açık renk kapsül içinde adıyla görünür.
struct FloatingTabBar: View {
    @EnvironmentObject var config: AppConfig
    let selected: Int
    let onSelect: (Int) -> Void

    private var tabs: [(String, String, String)] {
        [
            ("ic:home", config.s("TabHome", "Ana Sayfa"), "home"),
            ("ic:compass", config.s("TabExplore", "Keşfet"), "kesfet"),
            ("ic:bell", config.s("TabAnnouncements", "Duyurular"), "duyurular"),
            ("ic:grid", config.s("TabMore", "Menü"), "menu"),
        ]
    }

    var body: some View {
        HStack {
            ForEach(Array(tabs.enumerated()), id: \.offset) { i, t in
                let sel = i == selected
                Button { withAnimation(.easeInOut(duration: 0.25)) { onSelect(i) } } label: {
                    HStack(spacing: 8) {
                        AppIcon(icon: t.0, tint: sel ? config.header : Theme.sky)
                        if sel {
                            Text(t.1).font(.outfit(14, .semibold)).foregroundStyle(config.header).lineLimit(1)
                        }
                    }
                    .padding(.horizontal, sel ? 16 : 11)
                    .frame(height: 44)
                    .background(sel ? config.background : .clear, in: RoundedRectangle(cornerRadius: 14))
                }
                .buttonStyle(.plain)
                .accessibilityLabel(t.1)
                .frame(maxWidth: .infinity)
            }
        }
        .padding(.horizontal, 10)
        .frame(height: 66)
        .background(config.header, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .shadow(color: config.header.opacity(0.45), radius: 14, y: 8)
        .padding(.horizontal, 12)
        .padding(.bottom, 4)
    }
}

private struct Splash: View {
    var body: some View {
        ZStack {
            Theme.deep.ignoresSafeArea()
            VStack(spacing: 18) {
                Image("Logo").resizable().scaledToFit().frame(width: 120, height: 120)
                    .background(.white, in: Circle())
                Text("Şarköy Belediyesi").font(.outfit(20, .bold)).foregroundStyle(.white)
                ProgressView().tint(.white).padding(.top, 10)
            }
        }
    }
}
