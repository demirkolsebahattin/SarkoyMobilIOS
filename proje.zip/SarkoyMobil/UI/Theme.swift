import SwiftUI

/// "Sahil" teması: Marmara mavisi + gün batımı turuncusu
enum Theme {
    static let ink = Color(hex: "#0B2A3C")!
    static let muted = Color(hex: "#4E6878")!
    static let faint = Color(hex: "#5F7787")!
    static let line = Color(hex: "#D3E2EA")!
    static let foam = Color(hex: "#E1EEF4")!
    static let ground = Color(hex: "#F3F7F9")!
    static let sea = Color(hex: "#0E5C86")!
    static let deep = Color(hex: "#083A57")!
    static let abyss = Color(hex: "#062F47")!
    static let sun = Color(hex: "#F2A15F")!
    static let sunSoft = Color(hex: "#F7C08E")!
    static let sunText = Color(hex: "#B24E17")!
    static let sunBg = Color(hex: "#FDEBDD")!
    static let sky = Color(hex: "#CFE3EE")!
    static let danger = Color(hex: "#B42318")!
}

extension Font {
    /// Outfit yazı tipi (Resources/Fonts)
    static func outfit(_ size: CGFloat, _ weight: Font.Weight = .regular) -> Font {
        let name: String
        switch weight {
        case .bold, .heavy, .black: name = "Outfit-Bold"
        case .semibold: name = "Outfit-SemiBold"
        case .medium: name = "Outfit-Medium"
        default: name = "Outfit-Regular"
        }
        return .custom(name, size: size)
    }
}

extension Color {
    /// "#RRGGBB" veya "#AARRGGBB"
    init?(hex: String?) {
        guard var h = hex?.trimmingCharacters(in: .whitespaces), !h.isEmpty else { return nil }
        if h.hasPrefix("#") { h.removeFirst() }
        guard let v = UInt64(h, radix: 16) else { return nil }
        switch h.count {
        case 6:
            self.init(.sRGB, red: Double((v >> 16) & 0xFF) / 255, green: Double((v >> 8) & 0xFF) / 255,
                      blue: Double(v & 0xFF) / 255, opacity: 1)
        case 8:
            self.init(.sRGB, red: Double((v >> 16) & 0xFF) / 255, green: Double((v >> 8) & 0xFF) / 255,
                      blue: Double(v & 0xFF) / 255, opacity: Double((v >> 24) & 0xFF) / 255)
        default:
            return nil
        }
    }
}
