import SwiftUI

enum Route: Hashable {
    case place(Int)
    case page(String)
    case events
    case obituaries
    case projects
    case contact
}

/// Uygulama içi gezinme. Admin panelindeki "Tıklanınca" seçenekleri buradan çalışır.
@MainActor
final class Router: ObservableObject {
    static let shared = Router()

    /// 0 Ana Sayfa · 1 Keşfet · 2 Duyurular · 3 Menü
    @Published var tab = 0
    @Published var path: [Route] = []

    func goTab(_ i: Int) {
        path.removeAll()
        tab = i
    }

    func push(_ r: Route) { path.append(r) }
    func back() { if !path.isEmpty { path.removeLast() } }

    /// type: screen | page | url | phone
    func action(_ type: String, _ value: String) {
        switch type {
        case "screen": screen(value)
        case "page": push(.page(value))
        case "url": Links.open(value)
        case "phone": Links.open("tel:" + value.replacingOccurrences(of: " ", with: ""))
        default: break
        }
    }

    func screen(_ key: String) {
        switch key {
        case "home": goTab(0)
        case "kesfet": goTab(1)
        case "duyurular": goTab(2)
        case "menu": goTab(3)
        case "etkinlikler": push(.events)
        case "vefat": push(.obituaries)
        case "projeler": push(.projects)
        case "iletisim": push(.contact)
        default: break
        }
    }
}
