import SwiftUI

// ─── Yükleme durumu ──────────────────────────────────────────────────────────

enum LoadState<T> {
    case loading
    case failed
    case ok(T)
}

/// Loading / hata / içerik durumlarını tek yerde çizer.
struct StateView<T, Content: View>: View {
    let state: LoadState<T>
    let retry: () -> Void
    @ViewBuilder let content: (T) -> Content

    var body: some View {
        switch state {
        case .loading:
            ProgressView().tint(Theme.sea).frame(maxWidth: .infinity, maxHeight: .infinity)
        case .failed:
            ErrorBox(retry: retry)
        case .ok(let v):
            content(v)
        }
    }
}

struct ErrorBox: View {
    let retry: () -> Void
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: "wifi.slash").font(.system(size: 30)).foregroundStyle(Theme.faint)
            Text("Veriler alınamadı.").font(.outfit(15)).foregroundStyle(Theme.muted)
            #if DEBUG
            Text("Sunucu: \(Api.baseUrl)").font(.outfit(12)).foregroundStyle(Theme.faint)
            #endif
            Button("Tekrar dene", action: retry).font(.outfit(15, .semibold)).tint(Theme.sea)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(24)
    }
}

struct EmptyBox: View {
    let text: String
    var icon = "ic:search"
    var body: some View {
        VStack(spacing: 10) {
            AppIcon(icon: icon, tint: Theme.faint, size: 32)
            Text(text).font(.outfit(15)).foregroundStyle(Theme.faint)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 60)
    }
}

// ─── Görsel parçalar ─────────────────────────────────────────────────────────

/// Sunucudaki resim; yoksa / yüklenemezse fallback çizilir.
struct NetImage<Fallback: View>: View {
    let path: String?
    @ViewBuilder let fallback: () -> Fallback

    var body: some View {
        if let url = Api.imageURL(path) {
            AsyncImage(url: url) { phase in
                switch phase {
                case .success(let img): img.resizable().scaledToFill()
                case .failure: fallback()
                default: Rectangle().fill(Color(hex: "#E6EEF2")!)
                }
            }
        } else {
            fallback()
        }
    }
}

struct Badge: View {
    let text: String
    let color: Color
    var body: some View {
        Text(text)
            .font(.outfit(12, .semibold))
            .foregroundStyle(color)
            .padding(.horizontal, 10).padding(.vertical, 4)
            .background(color.opacity(0.12), in: Capsule())
    }
}

struct SectionHeader: View {
    let title: String
    var onAll: (() -> Void)? = nil
    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title).font(.outfit(19, .semibold)).foregroundStyle(Theme.ink)
            Spacer()
            if let onAll {
                Button("Tümü", action: onAll).font(.outfit(14, .medium)).tint(AppConfig.shared.primary)
            }
        }
        .padding(.horizontal, 18).padding(.top, 22).padding(.bottom, 10)
    }
}

struct Chip: View {
    let text: String
    var icon: String? = nil
    let selected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                if let icon { AppIcon(icon: icon, tint: selected ? .white : AppConfig.shared.primary, size: 17) }
                Text(text).font(.outfit(14, .medium))
            }
            .foregroundStyle(selected ? .white : Theme.ink)
            .padding(.horizontal, 14).frame(height: 40)
            .background(selected ? AppConfig.shared.primary : .white, in: Capsule())
            .overlay(Capsule().stroke(selected ? .clear : Theme.line, lineWidth: 1))
        }
        .buttonStyle(.plain)
    }
}

/// 44pt yuvarlatılmış kare ikon butonu
struct RoundIconButton: View {
    let icon: String
    let label: String
    var background: Color = .white
    var tint: Color = Theme.ink
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            AppIcon(icon: icon, tint: tint)
                .frame(width: 44, height: 44)
                .background(background, in: RoundedRectangle(cornerRadius: 14))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }
}

/// Açık renkli Sahil başlığı (geri butonu + büyük başlık)
struct SahilHeader: View {
    let title: String
    var subtitle: String? = nil
    var onBack: (() -> Void)? = nil

    var body: some View {
        HStack(spacing: 12) {
            if let onBack { RoundIconButton(icon: "ic:back", label: "Geri", action: onBack) }
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.outfit(24, .semibold)).foregroundStyle(Theme.ink).lineLimit(1)
                if let subtitle {
                    Text(subtitle).font(.outfit(12)).tracking(1.4).foregroundStyle(Theme.muted)
                }
            }
            Spacer()
        }
        .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 6)
    }
}

extension View {
    /// Beyaz kart
    func card(_ radius: CGFloat = 18) -> some View {
        background(.white, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
    }
}

// ─── Dış bağlantılar ─────────────────────────────────────────────────────────

@MainActor
enum Links {
    static func open(_ raw: String) {
        var u = raw.trimmingCharacters(in: .whitespaces)
        guard !u.isEmpty else { return }
        if !u.contains(":") { u = "https://" + u }
        if let url = URL(string: u.replacingOccurrences(of: " ", with: "")) {
            UIApplication.shared.open(url)
        }
    }
}
