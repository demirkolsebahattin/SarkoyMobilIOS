import SwiftUI

/// "ic:wave" gibi değerler uygulamanın çizim ikonu (Assets: ic_wave), diğerleri emoji olarak çizilir.
struct AppIcon: View {
    let icon: String
    var tint: Color = Theme.ink
    var size: CGFloat = 22

    var body: some View {
        if icon.hasPrefix("ic:"), let ui = UIImage(named: "ic_" + icon.dropFirst(3)) {
            Image(uiImage: ui)
                .renderingMode(.template)
                .resizable()
                .scaledToFit()
                .foregroundStyle(tint)
                .frame(width: size, height: size)
                .accessibilityHidden(true)
        } else {
            Text(icon).font(.system(size: size * 0.85))
        }
    }
}

enum IconMap {
    /// Menü kutusundaki ekran kodu → ikon
    static func forScreen(_ key: String) -> String? {
        [
            "duyurular": "ic:megaphone", "kesfet": "ic:compass", "etkinlikler": "ic:calendar",
            "vefat": "ic:tulip", "projeler": "ic:hardhat", "menu": "ic:grid", "iletisim": "ic:phone",
        ][key]
    }
}

/// Resmi olmayan içerik için deniz / bağ / fener / tepe çizimleri
enum Artwork: String {
    case sea = "scene_sea", vineyard = "scene_vineyard", lighthouse = "scene_lighthouse", hills = "scene_hills"

    static func forText(_ s: String) -> Artwork {
        let k = s.lowercased()
        if k.contains("etkinlik") || k.contains("bağ") || k.contains("festival") || k.contains("konser") { return .vineyard }
        if k.contains("duyuru") || k.contains("acil") || k == "su" { return .lighthouse }
        if k.contains("doğa") || k.contains("tarih") || k.contains("zeytin") { return .hills }
        return .sea
    }
}

struct SceneImage: View {
    let scene: Artwork
    var body: some View {
        Image(scene.rawValue).resizable().scaledToFill().accessibilityHidden(true)
    }
}
