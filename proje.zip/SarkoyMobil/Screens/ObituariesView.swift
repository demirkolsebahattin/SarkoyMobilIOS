import SwiftUI

struct ObituariesView: View {
    @EnvironmentObject var config: AppConfig
    @EnvironmentObject var router: Router
    @State private var state: LoadState<[Obituary]> = .loading

    var body: some View {
        VStack(spacing: 0) {
            SahilHeader(title: "Vefat İlanları", onBack: { router.back() })
            StateView(state: state, retry: { Task { await load() } }) { list in
                ScrollView {
                    LazyVStack(spacing: 12) {
                        Text(config.s("ObituaryNote", "Allah rahmet eylesin. Yakınlarına başsağlığı dileriz."))
                            .font(.outfit(13)).italic().foregroundStyle(Theme.muted)
                            .multilineTextAlignment(.center).frame(maxWidth: .infinity)
                        if list.isEmpty { EmptyBox(text: "Vefat ilanı bulunmuyor.", icon: "ic:tulip") }
                        ForEach(list) { ObituaryCard(item: $0) }
                    }
                    .padding(16)
                }
                .refreshable { await load() }
            }
        }
        .background(config.background)
        .task { await load() }
    }

    private func load() async {
        do { state = .ok(try await Api.obituaries()) } catch { state = .failed }
    }
}

private struct ObituaryCard: View {
    let item: Obituary
    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            NetImage(path: item.imageUrl) {
                ZStack { Color(hex: "#E9EEF1")!; AppIcon(icon: "ic:tulip", tint: Theme.faint, size: 28) }
            }
            .frame(width: 66, height: 84)
            .clipShape(RoundedRectangle(cornerRadius: 10))
            .grayscale(1)

            VStack(alignment: .leading, spacing: 4) {
                Text(item.fullName + (item.age.map { " (\($0))" } ?? ""))
                    .font(.outfit(17, .semibold)).foregroundStyle(Theme.ink)
                if let r = item.relatives, !r.isEmpty {
                    Text(r).font(.outfit(13)).foregroundStyle(Theme.muted)
                }
                line("ic:calendar", "Vefat: \(item.deathDateFormatted)").padding(.top, 4)
                if let fp = item.funeralPrayer, !fp.isEmpty {
                    line("ic:clock", fp + (item.funeralDateTimeFormatted.map { " · \($0)" } ?? ""))
                }
                if let b = item.burialPlace, !b.isEmpty { line("ic:pin", b) }
                if let c = item.condolenceAddress, !c.isEmpty { line("ic:home", "Taziye: \(c)") }
            }
            Spacer(minLength: 0)
        }
        .padding(14)
        .card()
    }

    private func line(_ icon: String, _ text: String) -> some View {
        HStack(alignment: .top, spacing: 6) {
            AppIcon(icon: icon, tint: Theme.muted, size: 15).padding(.top, 1)
            Text(text).font(.outfit(13)).foregroundStyle(Theme.ink)
        }
    }
}
