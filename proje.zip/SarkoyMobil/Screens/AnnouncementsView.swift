import SwiftUI

struct AnnouncementsView: View {
    @EnvironmentObject var config: AppConfig
    @EnvironmentObject var router: Router
    var isTab = false
    @State private var state: LoadState<[Announcement]> = .loading
    @State private var selected: String? = nil
    @State private var detail: Announcement? = nil

    var body: some View {
        VStack(spacing: 0) {
            SahilHeader(title: config.s("TabAnnouncements", "Duyurular"), onBack: backAction)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    Chip(text: "Tümü", selected: selected == nil) { selected = nil }
                    ForEach(config.cats("Announcement"), id: \.name) { c in
                        Chip(text: c.name, icon: c.icon.hasPrefix("ic:") ? c.icon : nil, selected: selected == c.name) {
                            selected = c.name
                        }
                    }
                }
                .padding(.horizontal, 16).padding(.vertical, 10)
            }
            StateView(state: state, retry: { Task { await load() } }) { all in
                let list = selected == nil ? all : all.filter { $0.category == selected }
                ScrollView {
                    LazyVStack(spacing: 10) {
                        if list.isEmpty { EmptyBox(text: "Bu kategoride duyuru yok.", icon: "ic:megaphone") }
                        ForEach(list) { a in
                            Button { detail = a } label: { AnnouncementRow(item: a, showContent: true) }.buttonStyle(.plain)
                        }
                    }
                    .padding(16)
                }
                .refreshable { await load() }
            }
        }
        .background(config.background)
        .task { if case .loading = state { await load() } }
        .sheet(item: $detail) { a in
            AnnouncementDetail(item: a)
                .presentationDetents([.medium, .large])
                .environmentObject(config)
        }
    }

    private var backAction: (() -> Void)? {
        if isTab { return nil }
        return { router.back() }
    }

    private func load() async {
        do { state = .ok(try await Api.announcements(limit: 100)) } catch {
            if case .ok = state { return }
            state = .failed
        }
    }
}

private struct AnnouncementDetail: View {
    @EnvironmentObject var config: AppConfig
    let item: Announcement

    var body: some View {
        let c = item.category == "Acil" ? Theme.danger : config.catColor("Announcement", item.category)
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                if Api.imageURL(item.imageUrl) != nil {
                    NetImage(path: item.imageUrl) { EmptyView() }
                        .frame(height: 190).frame(maxWidth: .infinity).clipped()
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                }
                HStack(spacing: 12) {
                    AppIcon(icon: config.catIcon("Announcement", item.category, "ic:megaphone"), tint: c, size: 22)
                        .frame(width: 44, height: 44)
                        .background(c.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
                    VStack(alignment: .leading) {
                        Text(item.category).font(.outfit(13, .semibold)).foregroundStyle(c)
                        Text(item.createdAtFormatted ?? "").font(.outfit(12)).foregroundStyle(Theme.faint)
                    }
                }
                Text(item.title).font(.outfit(21, .bold)).foregroundStyle(Theme.ink)
                Text(item.content).font(.outfit(15.5)).lineSpacing(5).foregroundStyle(Theme.ink)
            }
            .padding(22)
        }
    }
}
