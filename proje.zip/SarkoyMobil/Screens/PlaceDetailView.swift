import SwiftUI

struct PlaceDetailView: View {
    @EnvironmentObject var config: AppConfig
    @EnvironmentObject var router: Router
    let id: Int
    @State private var state: LoadState<Place> = .loading

    var body: some View {
        ZStack(alignment: .topLeading) {
            StateView(state: state, retry: { Task { await load() } }) { p in detail(p) }
            RoundIconButton(icon: "ic:back", label: "Geri", background: Color.black.opacity(0.35), tint: .white) {
                router.back()
            }
            .padding(.leading, 12).padding(.top, 4)
        }
        .background(config.background)
        .task { await load() }
    }

    private func detail(_ p: Place) -> some View {
        let c = config.catColor("Place", p.category)
        return ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                NetImage(path: p.imageUrl) { SceneImage(scene: Artwork.forText(p.category)) }
                    .frame(height: 300).frame(maxWidth: .infinity).clipped()
                VStack(alignment: .leading, spacing: 12) {
                    HStack(spacing: 6) {
                        Badge(text: p.category, color: c)
                        if p.isSlider == true { Badge(text: "Önerilen", color: config.primary) }
                    }
                    Text(p.name).font(.outfit(26, .bold)).foregroundStyle(Theme.ink)
                    HStack(spacing: 4) {
                        AppIcon(icon: "ic:pin", tint: Theme.faint, size: 15)
                        Text(p.location).font(.outfit(14)).foregroundStyle(Theme.faint)
                    }
                    Text(p.description).font(.outfit(16)).lineSpacing(5).foregroundStyle(Theme.ink).padding(.top, 6)

                    if let lat = p.latitude, let lng = p.longitude {
                        Button {
                            let q = p.name.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
                            Links.open("https://maps.apple.com/?ll=\(lat),\(lng)&q=\(q)")
                        } label: {
                            HStack(spacing: 8) {
                                AppIcon(icon: "ic:map", tint: .white, size: 20)
                                Text("Haritada Göster / Yol Tarifi").font(.outfit(16, .semibold))
                            }
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity).frame(height: 52)
                            .background(config.primary, in: RoundedRectangle(cornerRadius: 14))
                        }
                        .padding(.top, 14)
                    }
                }
                .padding(20)
            }
        }
        .ignoresSafeArea(edges: .top)
    }

    private func load() async {
        do { state = .ok(try await Api.place(id)) } catch { state = .failed }
    }
}
