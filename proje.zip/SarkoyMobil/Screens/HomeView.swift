import SwiftUI

/// Ana sayfa — Sahil teması. Slider, menü ve bölümler admin panelinden yönetilir.
struct HomeView: View {
    @EnvironmentObject var config: AppConfig
    @EnvironmentObject var router: Router

    @State private var loading = true
    @State private var hero: [SliderItem] = []
    @State private var places: [Place] = []
    @State private var announcements: [Announcement] = []
    @State private var events: [EventItem] = []

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                header
                ZStack(alignment: .bottom) {
                    HeroSlider(items: hero, interval: config.n("SliderInterval", 5)) { item in
                        if item.kind == "etkinlik" { router.push(.events) } else { router.goTab(2) }
                    }
                    .padding(.bottom, 36)
                    KartTopUpButton {
                        Links.open(config.s("KartTopUpUrl", "https://www.sarkoysosyaltesis.com"))
                    }
                }
                .padding(.horizontal, 16)

                let notice = config.s("NoticeText")
                if !notice.isEmpty { NoticeBanner(text: notice) }

                if config.b("ShowMenu") && !config.data.menu.isEmpty {
                    QuickGrid(items: config.data.menu) { router.action($0.actionType, $0.actionValue) }
                }

                if config.b("ShowSlider") && !places.isEmpty {
                    SectionHeader(title: config.s("SliderTitle", "Gezilecek Yerler")) { router.goTab(1) }
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            ForEach(places) { p in
                                Button { router.push(.place(p.id)) } label: { PlaceCard(place: p) }.buttonStyle(.plain)
                            }
                        }
                        .padding(.horizontal, 16)
                    }
                }

                if config.b("ShowEvents") && !events.isEmpty {
                    SectionHeader(title: config.s("EventsTitle", "Yaklaşan Etkinlikler")) { router.push(.events) }
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(events) { e in
                                Button { router.push(.events) } label: { EventMiniCard(event: e) }.buttonStyle(.plain)
                            }
                        }
                        .padding(.horizontal, 16)
                    }
                }

                if config.b("ShowAnnouncements") {
                    SectionHeader(title: config.s("AnnouncementsTitle", "Son Duyurular")) { router.goTab(2) }
                    VStack(spacing: 10) {
                        if announcements.isEmpty && !loading {
                            Text("Henüz duyuru yok.").font(.outfit(15)).foregroundStyle(Theme.faint)
                                .frame(maxWidth: .infinity).padding(20)
                        }
                        ForEach(announcements) { a in
                            Button { router.goTab(2) } label: { AnnouncementRow(item: a) }.buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, 16)
                }
            }
            .padding(.bottom, 20)
        }
        .background(config.background)
        .refreshable {
            await config.load()
            await loadAll()
        }
        .task { if loading { await loadAll(); loading = false } }
    }

    private var header: some View {
        HStack(spacing: 12) {
            Image("Logo").resizable().scaledToFit().frame(width: 44, height: 44)
                .background(.white, in: Circle())
                .accessibilityLabel("Şarköy Belediyesi logosu")
            VStack(alignment: .leading, spacing: 0) {
                Text(config.s("AppTitle", "Şarköy Belediyesi")).font(.outfit(17, .semibold)).foregroundStyle(Theme.ink)
                Text(config.s("AppSubtitle", "Hoş geldiniz")).font(.outfit(13)).foregroundStyle(Theme.muted)
            }
            Spacer()
            RoundIconButton(icon: "ic:bell", label: "Bildirimler") { router.goTab(2) }
        }
        .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 12)
    }

    @MainActor
    private func loadAll() async {
        let showH = config.b("ShowHeroSlider"), showP = config.b("ShowSlider")
        let showA = config.b("ShowAnnouncements"), showE = config.b("ShowEvents")
        let annLimit = config.n("HomeAnnouncementCount", 5), evLimit = config.n("HomeEventCount", 3)

        async let h: [SliderItem] = showH ? ((try? await Api.homeSlider()) ?? []) : []
        async let p: [Place] = showP ? ((try? await Api.sliderPlaces()) ?? []) : []
        async let a: [Announcement] = showA ? ((try? await Api.announcements(limit: annLimit)) ?? []) : []
        async let e: [EventItem] = showE ? ((try? await Api.events()) ?? []) : []
        let (hh, pp, aa, ee) = await (h, p, a, e)
        hero = hh; places = pp; announcements = aa
        events = Array(ee.prefix(evLimit))
    }
}

// ─── ÜST SLIDER: günün etkinlik, haber ve duyuruları ─────────────────────────

private struct HeroSlide: Identifiable {
    let id: String
    let kind: String
    let label: String
    let title: String
    let meta: String
    let imageUrl: String?
    let source: SliderItem?
}

private struct HeroSlider: View {
    @EnvironmentObject var config: AppConfig
    let items: [SliderItem]
    let interval: Int
    let onTap: (SliderItem) -> Void
    @State private var index = 0

    private var slides: [HeroSlide] {
        let list = items.map { it -> HeroSlide in
            let label: String
            switch it.kind {
            case "etkinlik": label = "ETKİNLİK"
            case "haber": label = "HABER"
            default: label = it.urgent ? "ACİL" : "DUYURU"
            }
            return HeroSlide(id: "\(it.kind)-\(it.id)", kind: it.kind, label: label, title: it.title,
                             meta: it.meta, imageUrl: it.imageUrl, source: it)
        }
        if !list.isEmpty { return list }
        // Admin'den öğe gelmezse karşılama slaytı
        return [HeroSlide(id: "hosgeldin", kind: "haber", label: config.s("HeroTagline", "MARMARA'NIN KIYISINDA"),
                          title: config.s("HeroTitle", "Denize, bağa ve zeytine açılan kent."),
                          meta: "", imageUrl: nil, source: nil)]
    }

    var body: some View {
        let s = slides
        ZStack(alignment: .bottomLeading) {
            TabView(selection: $index) {
                ForEach(Array(s.enumerated()), id: \.element.id) { i, slide in
                    slideView(slide).tag(i)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never))

            if s.count > 1 {
                HStack(spacing: 6) {
                    ForEach(0..<s.count, id: \.self) { i in
                        Capsule().fill(i == index ? Color.white : Color.white.opacity(0.45))
                            .frame(width: i == index ? 22 : 8, height: 6)
                    }
                }
                .padding(.leading, 20).padding(.bottom, 24)
                .animation(.easeInOut(duration: 0.25), value: index)
            }
        }
        .frame(height: 320)
        .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
        .task(id: s.count) {
            guard s.count > 1 else { return }
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: UInt64(max(2, min(interval, 30))) * 1_000_000_000)
                withAnimation(.easeInOut(duration: 0.5)) { index = (index + 1) % s.count }
            }
        }
    }

    @ViewBuilder private func slideView(_ s: HeroSlide) -> some View {
        ZStack(alignment: .bottomLeading) {
            NetImage(path: s.imageUrl) { SceneImage(scene: Artwork.forText(s.kind)) }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .clipped()
            if s.imageUrl != nil {
                LinearGradient(stops: [.init(color: .clear, location: 0.4), .init(color: Theme.abyss.opacity(0.92), location: 1)],
                               startPoint: .top, endPoint: .bottom)
            }
            VStack(alignment: .leading, spacing: 8) {
                if s.source == nil {
                    Text(s.label).font(.outfit(11, .bold)).tracking(1.6).foregroundStyle(Theme.sunSoft)
                } else {
                    Text(s.label).font(.outfit(11, .bold)).tracking(1.6).foregroundStyle(Theme.abyss)
                        .padding(.horizontal, 10).padding(.vertical, 5)
                        .background(chipColor(s.label), in: RoundedRectangle(cornerRadius: 10))
                }
                Text(s.title).font(.outfit(26, .semibold)).foregroundStyle(.white).lineLimit(3)
                if !s.meta.isEmpty {
                    Text(s.meta).font(.outfit(13)).foregroundStyle(Theme.sky).lineLimit(1)
                }
            }
            .padding(.horizontal, 20).padding(.bottom, 44)
        }
        .contentShape(Rectangle())
        .onTapGesture { if let src = s.source { onTap(src) } }
    }

    private func chipColor(_ label: String) -> Color {
        switch label {
        case "ETKİNLİK": return Theme.sun
        case "HABER": return Color(hex: "#9ED3E8")!
        case "ACİL": return Color(hex: "#F6B3A0")!
        default: return .white
        }
    }
}

/// Şarköy Kart'a para yükleme — adres admin panelinden (Uygulama Ayarları → Şarköy Kart)
private struct KartTopUpButton: View {
    @EnvironmentObject var config: AppConfig
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                AppIcon(icon: "ic:card", tint: Theme.sunText, size: 24)
                    .frame(width: 44, height: 44)
                    .background(Theme.sunBg, in: RoundedRectangle(cornerRadius: 14))
                VStack(alignment: .leading, spacing: 1) {
                    Text(config.s("KartTopUpTitle", "Şarköy Kart")).font(.outfit(16, .semibold)).foregroundStyle(Theme.ink)
                    Text(config.s("KartTopUpSubtitle", "Karta para yükle")).font(.outfit(13)).foregroundStyle(Theme.muted)
                }
                Spacer()
                HStack(spacing: 6) {
                    Text("Yükle").font(.outfit(15, .semibold))
                    AppIcon(icon: "ic:arrow", tint: Theme.abyss, size: 18)
                }
                .foregroundStyle(Theme.abyss)
                .padding(.horizontal, 14).frame(height: 44)
                .background(Theme.sun, in: RoundedRectangle(cornerRadius: 14))
            }
            .padding(10)
            .background(.white, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .shadow(color: Theme.deep.opacity(0.25), radius: 14, y: 8)
            .padding(.horizontal, 10)
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Şarköy Kart'a para yükle")
    }
}

private struct NoticeBanner: View {
    let text: String
    var body: some View {
        HStack(spacing: 10) {
            AppIcon(icon: "ic:megaphone", tint: Theme.sunText, size: 20)
            Text(text).font(.outfit(14)).foregroundStyle(Color(hex: "#8A3A10")!)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(12)
        .background(Theme.sunBg, in: RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Theme.sunSoft, lineWidth: 1))
        .padding(.horizontal, 16).padding(.top, 16)
    }
}

// ─── HIZLI ERİŞİM ────────────────────────────────────────────────────────────

private struct QuickGrid: View {
    @EnvironmentObject var config: AppConfig
    let items: [MenuItemDto]
    let onTap: (MenuItemDto) -> Void

    var body: some View {
        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: 3), spacing: 10) {
            ForEach(items) { m in
                Button { onTap(m) } label: {
                    VStack(spacing: 8) {
                        AppIcon(icon: icon(for: m), tint: iconColor(m), size: 24)
                            .frame(width: 48, height: 48)
                            .background(Color(hex: m.bgColor) ?? Theme.foam, in: RoundedRectangle(cornerRadius: 16))
                        Text(m.title).font(.outfit(13, .medium)).foregroundStyle(Theme.ink).lineLimit(1)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .card()
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 16).padding(.top, 20)
    }

    private func icon(for m: MenuItemDto) -> String {
        if m.icon.hasPrefix("ic:") { return m.icon }
        if m.actionType == "screen", let i = IconMap.forScreen(m.actionValue) { return i }
        return m.icon
    }

    private func iconColor(_ m: MenuItemDto) -> Color {
        // Koyu yazı rengi seçildiyse ikon ana renkle çizilir
        let c = (m.color.uppercased() == "#0B2A3C") ? nil : Color(hex: m.color)
        return c ?? config.primary
    }
}

// ─── KARTLAR ─────────────────────────────────────────────────────────────────

private struct PlaceCard: View {
    let place: Place
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            NetImage(path: place.imageUrl) { SceneImage(scene: Artwork.forText(place.category)) }
                .frame(width: 210, height: 110).clipped()
            VStack(alignment: .leading, spacing: 2) {
                Text(place.name).font(.outfit(15, .semibold)).foregroundStyle(Theme.ink).lineLimit(1)
                Text("\(place.location) · \(place.category)").font(.outfit(12)).foregroundStyle(Theme.muted).lineLimit(1)
            }
            .padding(12)
        }
        .frame(width: 210, alignment: .leading)
        .card()
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

private struct EventMiniCard: View {
    @EnvironmentObject var config: AppConfig
    let event: EventItem
    var body: some View {
        HStack(spacing: 12) {
            DateBox(day: event.day, month: event.month, color: config.catColor("Event", event.category))
            VStack(alignment: .leading, spacing: 2) {
                Text(event.title).font(.outfit(14, .semibold)).foregroundStyle(Theme.ink).lineLimit(2)
                Text("\(event.timeFormatted) · \(event.location)").font(.outfit(12)).foregroundStyle(Theme.muted).lineLimit(1)
            }
            Spacer(minLength: 0)
        }
        .padding(12)
        .frame(width: 262)
        .card()
    }
}

struct DateBox: View {
    let day: String
    let month: String
    let color: Color
    var body: some View {
        VStack(spacing: 0) {
            Text(day).font(.outfit(20, .bold))
            Text(month).font(.outfit(10, .semibold)).tracking(1)
        }
        .foregroundStyle(color)
        .frame(width: 52).padding(.vertical, 8)
        .background(color.opacity(0.10), in: RoundedRectangle(cornerRadius: 12))
    }
}

struct AnnouncementRow: View {
    @EnvironmentObject var config: AppConfig
    let item: Announcement
    var showContent = false

    var body: some View {
        let urgent = item.category == "Acil"
        let c = urgent ? Theme.danger : config.catColor("Announcement", item.category)
        HStack(alignment: .top, spacing: 12) {
            AppIcon(icon: config.catIcon("Announcement", item.category, "ic:megaphone"), tint: c, size: 21)
                .frame(width: 42, height: 42)
                .background(c.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))
            VStack(alignment: .leading, spacing: 3) {
                Text("\(urgent ? "ACİL" : item.category) · \(item.createdAtFormatted ?? "")")
                    .font(.outfit(12, .medium)).foregroundStyle(urgent ? c : Theme.muted).lineLimit(1)
                Text(item.title).font(.outfit(15, .semibold)).foregroundStyle(Theme.ink).lineLimit(2)
                if showContent {
                    Text(item.content).font(.outfit(13)).foregroundStyle(Theme.muted).lineLimit(3)
                }
            }
            Spacer(minLength: 0)
        }
        .padding(14)
        .card()
        .overlay(urgent ? RoundedRectangle(cornerRadius: 18).stroke(Color(hex: "#F6B3A0")!, lineWidth: 1) : nil)
    }
}
