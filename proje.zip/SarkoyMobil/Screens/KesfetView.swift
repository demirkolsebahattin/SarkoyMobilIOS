import SwiftUI

struct KesfetView: View {
    @EnvironmentObject var config: AppConfig
    @EnvironmentObject var router: Router
    @State private var state: LoadState<([Place], [Place])> = .loading
    @State private var selected: String? = nil

    var body: some View {
        VStack(spacing: 0) {
            SahilHeader(title: config.s("KesfetTitle", "Şarköy'ü Keşfet"),
                        subtitle: config.s("KesfetSubtitle", "SAHİL · BAĞ · ZEYTİN · TARİH"))
            StateView(state: state, retry: { Task { await load() } }) { data in
                content(featured: data.0, places: data.1)
            }
        }
        .background(config.background)
        .task { if case .loading = state { await load() } }
    }

    @ViewBuilder private func content(featured: [Place], places: [Place]) -> some View {
        let used = Set(places.map(\.category))
        let ordered = config.cats("Place").map(\.name).filter { used.contains($0) }
        let categories = ordered + used.filter { !ordered.contains($0) }.sorted()
        let filtered = selected == nil ? places : places.filter { $0.category == selected }
        let hero = (selected == nil ? featured : featured.filter { $0.category == selected }).first

        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        Chip(text: "Tümü", icon: "ic:compass", selected: selected == nil) { selected = nil }
                        ForEach(categories, id: \.self) { c in
                            Chip(text: c, icon: config.catIcon("Place", c), selected: selected == c) { selected = c }
                        }
                    }
                    .padding(.horizontal, 16).padding(.vertical, 12)
                }

                if let hero {
                    Button { router.push(.place(hero.id)) } label: { FeaturedCard(place: hero) }
                        .buttonStyle(.plain).padding(.horizontal, 16)
                }

                Text("\(selected ?? "Tüm yerler") · \(filtered.count) yer")
                    .font(.outfit(14)).foregroundStyle(Theme.muted)
                    .padding(.horizontal, 18).padding(.top, 20).padding(.bottom, 8)

                if filtered.isEmpty { EmptyBox(text: "Bu kategoride yer bulunamadı") }

                VStack(spacing: 10) {
                    ForEach(filtered) { p in
                        Button { router.push(.place(p.id)) } label: { PlaceRow(place: p) }.buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 16)
            }
            .padding(.bottom, 20)
        }
        .refreshable { await load() }
    }

    private func load() async {
        do {
            async let f = Api.sliderPlaces()
            async let p = Api.places()
            state = .ok(try await (f, p))
        } catch {
            if case .ok = state { return }
            state = .failed
        }
    }
}

private struct FeaturedCard: View {
    let place: Place
    var body: some View {
        ZStack(alignment: .bottom) {
            NetImage(path: place.imageUrl) { SceneImage(scene: .hills) }
                .frame(height: 236).frame(maxWidth: .infinity).clipped()
            HStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("ÖNERİLEN").font(.outfit(11, .semibold)).tracking(1.6).foregroundStyle(Theme.sunSoft)
                    Text(place.name).font(.outfit(20, .semibold)).foregroundStyle(.white).lineLimit(1)
                    Text(place.description).font(.outfit(13)).foregroundStyle(Theme.sky).lineLimit(1)
                }
                Spacer()
                AppIcon(icon: "ic:arrow", tint: Theme.abyss, size: 20)
                    .frame(width: 44, height: 44).background(Theme.sun, in: Circle())
            }
            .padding(.horizontal, 18).padding(.vertical, 16)
            .background(Theme.abyss.opacity(0.82))
        }
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
    }
}

private struct PlaceRow: View {
    @EnvironmentObject var config: AppConfig
    let place: Place
    var body: some View {
        HStack(spacing: 12) {
            NetImage(path: place.imageUrl) { SceneImage(scene: Artwork.forText(place.category)) }
                .frame(width: 64, height: 64)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            VStack(alignment: .leading, spacing: 2) {
                Text(place.name).font(.outfit(16, .semibold)).foregroundStyle(Theme.ink).lineLimit(1)
                Text(place.description).font(.outfit(13)).foregroundStyle(Theme.muted).lineLimit(1)
                HStack(spacing: 4) {
                    AppIcon(icon: "ic:pin", tint: config.primary, size: 14)
                    Text(place.location).font(.outfit(12)).foregroundStyle(config.primary)
                }
            }
            Spacer(minLength: 0)
            AppIcon(icon: "ic:chevron", tint: Color(hex: "#B9CBD5")!, size: 18)
        }
        .padding(10)
        .card()
    }
}
