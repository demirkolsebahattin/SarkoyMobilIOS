import SwiftUI

/// Admin panelindeki İçerik Sayfaları. Boş satır = paragraf, "## " = ara başlık.
struct PageView: View {
    @EnvironmentObject var config: AppConfig
    @EnvironmentObject var router: Router
    let slug: String
    @State private var state: LoadState<ContentPage> = .loading

    var body: some View {
        VStack(spacing: 0) {
            SahilHeader(title: title, onBack: { router.back() })
            StateView(state: state, retry: { Task { await load() } }) { p in
                ScrollView {
                    VStack(alignment: .leading, spacing: 6) {
                        if Api.imageURL(p.imageUrl) != nil {
                            NetImage(path: p.imageUrl) { EmptyView() }
                                .frame(height: 200).frame(maxWidth: .infinity).clipped()
                                .clipShape(RoundedRectangle(cornerRadius: 18))
                                .padding(.bottom, 10)
                        }
                        ForEach(Array(lines(p.content).enumerated()), id: \.offset) { _, line in
                            if line.isEmpty {
                                Spacer().frame(height: 8)
                            } else if line.hasPrefix("## ") {
                                Text(String(line.dropFirst(3))).font(.outfit(18, .semibold))
                                    .foregroundStyle(config.primary).padding(.top, 8)
                            } else {
                                Text(line).font(.outfit(16)).lineSpacing(5).foregroundStyle(Theme.ink)
                            }
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(20)
                }
            }
        }
        .background(config.background)
        .task { await load() }
    }

    private var title: String {
        if case .ok(let p) = state { return p.title }
        return config.data.pages.first { $0.slug == slug }?.title ?? ""
    }

    private func lines(_ s: String) -> [String] {
        s.replacingOccurrences(of: "\r\n", with: "\n").components(separatedBy: "\n")
            .map { $0.trimmingCharacters(in: .whitespaces) }
    }

    private func load() async {
        do { state = .ok(try await Api.page(slug)) } catch { state = .failed }
    }
}
