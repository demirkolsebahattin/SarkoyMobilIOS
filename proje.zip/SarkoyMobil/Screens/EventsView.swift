import SwiftUI

struct EventsView: View {
    @EnvironmentObject var config: AppConfig
    @EnvironmentObject var router: Router
    @State private var past = false
    @State private var state: LoadState<[EventItem]> = .loading
    @State private var detail: EventItem? = nil

    var body: some View {
        VStack(spacing: 0) {
            SahilHeader(title: "Etkinlikler", onBack: { router.back() })
            HStack(spacing: 8) {
                Chip(text: "Yaklaşan", selected: !past) { past = false }
                Chip(text: "Geçmiş", selected: past) { past = true }
                Spacer()
            }
            .padding(.horizontal, 16).padding(.vertical, 10)
            StateView(state: state, retry: { Task { await load() } }) { list in
                ScrollView {
                    LazyVStack(spacing: 12) {
                        if list.isEmpty { EmptyBox(text: past ? "Geçmiş etkinlik yok." : "Yaklaşan etkinlik yok.", icon: "ic:calendar") }
                        ForEach(list) { e in
                            Button { detail = e } label: { EventCard(event: e) }.buttonStyle(.plain)
                        }
                    }
                    .padding(16)
                }
                .refreshable { await load() }
            }
        }
        .background(config.background)
        .task(id: past) { state = .loading; await load() }
        .sheet(item: $detail) { e in
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    if Api.imageURL(e.imageUrl) != nil {
                        NetImage(path: e.imageUrl) { EmptyView() }
                            .frame(height: 200).frame(maxWidth: .infinity).clipped()
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                    }
                    Text(e.title).font(.outfit(22, .bold)).foregroundStyle(Theme.ink)
                    Label { Text("\(e.dateFormatted) · \(e.timeFormatted)") } icon: { AppIcon(icon: "ic:calendar", tint: Theme.muted, size: 16) }
                        .font(.outfit(14)).foregroundStyle(Theme.muted)
                    Label { Text(e.location) } icon: { AppIcon(icon: "ic:pin", tint: Theme.muted, size: 16) }
                        .font(.outfit(14)).foregroundStyle(Theme.muted)
                    Text(e.description).font(.outfit(15.5)).lineSpacing(5).foregroundStyle(Theme.ink).padding(.top, 6)
                }
                .padding(22)
            }
            .presentationDetents([.medium, .large])
        }
    }

    private func load() async {
        do { state = .ok(try await Api.events(past: past)) } catch { state = .failed }
    }
}

private struct EventCard: View {
    @EnvironmentObject var config: AppConfig
    let event: EventItem
    var body: some View {
        let c = config.catColor("Event", event.category)
        VStack(alignment: .leading, spacing: 0) {
            if Api.imageURL(event.imageUrl) != nil {
                NetImage(path: event.imageUrl) { SceneImage(scene: .vineyard) }
                    .frame(height: 170).frame(maxWidth: .infinity).clipped()
            }
            HStack(spacing: 12) {
                DateBox(day: event.day, month: event.month, color: c)
                VStack(alignment: .leading, spacing: 3) {
                    Text(event.category.uppercased(with: Locale(identifier: "tr_TR")))
                        .font(.outfit(11, .bold)).tracking(0.8).foregroundStyle(c)
                    Text(event.title).font(.outfit(16, .semibold)).foregroundStyle(Theme.ink)
                    Text("\(event.timeFormatted) · \(event.location)").font(.outfit(13)).foregroundStyle(Theme.muted).lineLimit(1)
                }
                Spacer(minLength: 0)
            }
            .padding(14)
        }
        .card()
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}
