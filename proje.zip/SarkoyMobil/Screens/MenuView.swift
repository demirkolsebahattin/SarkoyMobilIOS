import SwiftUI

/// 4. sekme: içerik sayfaları + iletişim + sosyal medya (hepsi admin panelinden)
struct MenuView: View {
    @EnvironmentObject var config: AppConfig
    @EnvironmentObject var router: Router

    var body: some View {
        VStack(spacing: 0) {
            SahilHeader(title: config.s("TabMore", "Menü"))
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    if !config.data.pages.isEmpty {
                        VStack(spacing: 0) {
                            ForEach(Array(config.data.pages.enumerated()), id: \.element.id) { i, p in
                                if i > 0 { Divider().padding(.horizontal, 16) }
                                Button { router.push(.page(p.slug)) } label: {
                                    HStack(spacing: 14) {
                                        AppIcon(icon: p.icon, tint: config.primary, size: 22).frame(width: 28)
                                        VStack(alignment: .leading, spacing: 2) {
                                            Text(p.title).font(.outfit(15, .semibold)).foregroundStyle(Theme.ink)
                                            if let s = p.summary, !s.isEmpty {
                                                Text(s).font(.outfit(12)).foregroundStyle(Theme.faint)
                                            }
                                        }
                                        Spacer()
                                        AppIcon(icon: "ic:chevron", tint: Color(hex: "#B9CBD5")!, size: 16)
                                    }
                                    .padding(16)
                                    .contentShape(Rectangle())
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .card()
                    }
                    ContactSection()
                    Text("Sürüm \(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "")")
                        .font(.outfit(12)).foregroundStyle(Theme.faint).frame(maxWidth: .infinity)
                }
                .padding(16)
            }
        }
        .background(config.background)
    }
}

struct ContactView: View {
    @EnvironmentObject var config: AppConfig
    @EnvironmentObject var router: Router
    var body: some View {
        VStack(spacing: 0) {
            SahilHeader(title: "İletişim", onBack: { router.back() })
            ScrollView { ContactSection().padding(16) }
        }
        .background(config.background)
    }
}

struct ContactSection: View {
    @EnvironmentObject var config: AppConfig

    private struct Row: Identifiable {
        let id = UUID()
        let icon: String, label: String, value: String, link: String?
    }

    var body: some View {
        let phone = config.s("Phone"), wa = config.s("WhatsApp"), email = config.s("Email")
        let web = config.s("Website"), mapUrl = config.s("MapUrl")
        let rows = [
            Row(icon: "ic:phone", label: "Telefon", value: phone, link: "tel:" + phone.replacingOccurrences(of: " ", with: "")),
            Row(icon: "ic:chat", label: "WhatsApp", value: wa, link: "https://wa.me/" + wa.filter(\.isNumber)),
            Row(icon: "ic:mail", label: "E-posta", value: email, link: "mailto:" + email),
            Row(icon: "ic:globe", label: "Web Sitesi", value: web, link: web),
            Row(icon: "ic:pin", label: "Adres", value: config.s("Address"), link: mapUrl.isEmpty ? nil : mapUrl),
            Row(icon: "ic:clock", label: "Çalışma Saatleri", value: config.s("WorkingHours"), link: nil),
        ].filter { !$0.value.isEmpty }
        let socials = [("Facebook", config.s("Facebook")), ("Instagram", config.s("Instagram")),
                       ("X", config.s("X")), ("YouTube", config.s("YouTube"))].filter { !$0.1.isEmpty }

        VStack(alignment: .leading, spacing: 10) {
            if !rows.isEmpty || !socials.isEmpty {
                Text("İletişim").font(.outfit(17, .semibold)).foregroundStyle(Theme.ink).padding(.leading, 4)
            }
            if !rows.isEmpty {
                VStack(spacing: 0) {
                    ForEach(Array(rows.enumerated()), id: \.element.id) { i, r in
                        if i > 0 { Divider().padding(.horizontal, 16) }
                        Button { if let l = r.link { Links.open(l) } } label: {
                            HStack(spacing: 16) {
                                AppIcon(icon: r.icon, tint: config.primary)
                                VStack(alignment: .leading, spacing: 1) {
                                    Text(r.label).font(.outfit(12)).foregroundStyle(Theme.faint)
                                    Text(r.value).font(.outfit(15)).foregroundStyle(Theme.ink)
                                }
                                Spacer()
                            }
                            .padding(16)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .disabled(r.link == nil)
                    }
                }
                .card()
            }
            if !socials.isEmpty {
                HStack(spacing: 10) {
                    ForEach(socials, id: \.0) { s in
                        Button(s.0) { Links.open(s.1) }
                            .font(.outfit(14, .medium)).foregroundStyle(Theme.ink)
                            .padding(.horizontal, 14).frame(height: 40)
                            .background(.white, in: Capsule())
                    }
                }
                .padding(.top, 4)
            }
        }
    }
}
