import SwiftUI

struct ProjectsView: View {
    @EnvironmentObject var config: AppConfig
    @EnvironmentObject var router: Router
    @State private var status: String? = nil
    @State private var state: LoadState<[Project]> = .loading
    @State private var detail: Project? = nil
    private let statuses: [String?] = [nil, "Devam Eden", "Planlanan", "Tamamlanan"]

    var body: some View {
        VStack(spacing: 0) {
            SahilHeader(title: "Projeler", onBack: { router.back() })
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(statuses, id: \.self) { s in
                        Chip(text: s ?? "Tümü", selected: status == s) { status = s }
                    }
                }
                .padding(.horizontal, 16).padding(.vertical, 10)
            }
            StateView(state: state, retry: { Task { await load() } }) { list in
                ScrollView {
                    LazyVStack(spacing: 12) {
                        if list.isEmpty { EmptyBox(text: "Proje bulunmuyor.", icon: "ic:hardhat") }
                        ForEach(list) { p in
                            Button { detail = p } label: { ProjectCard(project: p) }.buttonStyle(.plain)
                        }
                    }
                    .padding(16)
                }
                .refreshable { await load() }
            }
        }
        .background(config.background)
        .task(id: status) { state = .loading; await load() }
        .sheet(item: $detail) { p in
            ScrollView {
                VStack(alignment: .leading, spacing: 8) {
                    Text(p.title).font(.outfit(22, .bold)).foregroundStyle(Theme.ink).padding(.bottom, 6)
                    info("Durum", "\(p.status) (%\(p.progress))")
                    if let v = p.location, !v.isEmpty { info("Konum", v) }
                    if let v = p.budget, !v.isEmpty { info("Bütçe", v) }
                    if let v = p.startDateFormatted { info("Başlangıç", v) }
                    if let v = p.endDateFormatted { info("Bitiş", v) }
                    Text(p.description).font(.outfit(15.5)).lineSpacing(5).foregroundStyle(Theme.ink).padding(.top, 10)
                }
                .padding(22)
            }
            .presentationDetents([.medium, .large])
        }
    }

    private func info(_ k: String, _ v: String) -> some View {
        HStack(alignment: .top) {
            Text(k).font(.outfit(14)).foregroundStyle(Theme.muted).frame(width: 90, alignment: .leading)
            Text(v).font(.outfit(14, .semibold)).foregroundStyle(Theme.ink)
        }
    }

    private func load() async {
        do { state = .ok(try await Api.projects(status: status)) } catch { state = .failed }
    }
}

func statusColor(_ s: String) -> Color {
    switch s {
    case "Tamamlanan": return Color(hex: "#3B6D11")!
    case "Planlanan": return Theme.sea
    default: return Theme.sunText
    }
}

private struct ProjectCard: View {
    let project: Project
    var body: some View {
        let c = statusColor(project.status)
        VStack(alignment: .leading, spacing: 0) {
            if Api.imageURL(project.imageUrl) != nil {
                NetImage(path: project.imageUrl) { SceneImage(scene: .hills) }
                    .frame(height: 170).frame(maxWidth: .infinity).clipped()
            }
            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Badge(text: project.status, color: c)
                    Spacer()
                    if let l = project.location, !l.isEmpty {
                        Text(l).font(.outfit(12)).foregroundStyle(Theme.muted)
                    }
                }
                Text(project.title).font(.outfit(16, .semibold)).foregroundStyle(Theme.ink)
                Text(project.description).font(.outfit(13)).foregroundStyle(Theme.muted).lineLimit(2)
                HStack(spacing: 10) {
                    ProgressView(value: Double(project.progress), total: 100).tint(c)
                    Text("%\(project.progress)").font(.outfit(13, .bold)).foregroundStyle(c)
                }
                .padding(.top, 6)
            }
            .padding(14)
        }
        .card()
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}
