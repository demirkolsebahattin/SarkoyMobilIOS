import Foundation

/// SarkoyApi istemcisi. Adres: project.yml → SARKOY_API_URL (Info.plist "SarkoyApiUrl").
enum Api {
    static let baseUrl: String = {
        let v = (Bundle.main.object(forInfoDictionaryKey: "SarkoyApiUrl") as? String) ?? ""
        let url = v.isEmpty ? "http://localhost:51326" : v
        return url.hasSuffix("/") ? String(url.dropLast()) : url
    }()

    private static let session: URLSession = {
        let c = URLSessionConfiguration.default
        c.timeoutIntervalForRequest = 8
        c.timeoutIntervalForResource = 15
        return URLSession(configuration: c)
    }()

    static func get<T: Decodable>(_ path: String, query: [String: String?] = [:]) async throws -> T {
        var comps = URLComponents(string: baseUrl + path)!
        let items = query.compactMap { k, v in v.map { URLQueryItem(name: k, value: $0) } }
        if !items.isEmpty { comps.queryItems = items }
        let (data, resp) = try await session.data(from: comps.url!)
        guard let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw URLError(.badServerResponse)
        }
        return try JSONDecoder().decode(T.self, from: data)
    }

    // ─── Uç noktalar ─────────────────────────────────────────────────────────
    static func config() async throws -> AppConfigDto { try await get("/api/app/config") }
    static func page(_ slug: String) async throws -> ContentPage {
        try await get("/api/app/pages/\(slug.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? slug)")
    }
    static func homeSlider() async throws -> [SliderItem] { try await get("/api/home/slider") }
    static func places() async throws -> [Place] { try await get("/api/places") }
    static func sliderPlaces() async throws -> [Place] { try await get("/api/places/slider") }
    static func place(_ id: Int) async throws -> Place { try await get("/api/places/\(id)") }
    static func announcements(limit: Int = 50) async throws -> [Announcement] {
        try await get("/api/announcements", query: ["limit": String(limit)])
    }
    static func events(past: Bool = false) async throws -> [EventItem] {
        try await get("/api/events", query: ["past": past ? "true" : "false"])
    }
    static func obituaries() async throws -> [Obituary] { try await get("/api/obituaries") }
    static func projects(status: String? = nil) async throws -> [Project] {
        try await get("/api/projects", query: ["status": status])
    }

    /// "/images/x.jpg" → tam adres
    static func imageURL(_ path: String?) -> URL? {
        guard let p = path, !p.isEmpty else { return nil }
        return URL(string: p.hasPrefix("http") ? p : baseUrl + p)
    }
}
