import Foundation

// API (ASP.NET Core) camelCase JSON alanlarıyla birebir aynı isimler.
// API'de null olabilecek alanlar opsiyonel.

struct Place: Codable, Identifiable, Hashable {
    let id: Int
    let name: String
    let description: String
    let category: String
    let location: String
    let latitude: Double?
    let longitude: Double?
    let isSlider: Bool?
    let imageUrl: String?
}

struct Announcement: Codable, Identifiable, Hashable {
    let id: Int
    let title: String
    let content: String
    let category: String
    let createdAtFormatted: String?
    let imageUrl: String?
}

struct SliderItem: Codable, Identifiable, Hashable {
    let kind: String          // etkinlik, duyuru, haber
    let id: Int
    let title: String
    let meta: String
    let category: String
    let imageUrl: String?
    let urgent: Bool
}

struct Obituary: Codable, Identifiable, Hashable {
    let id: Int
    let fullName: String
    let relatives: String?
    let age: Int?
    let deathDateFormatted: String
    let funeralPrayer: String?
    let funeralDateTimeFormatted: String?
    let burialPlace: String?
    let condolenceAddress: String?
    let imageUrl: String?
}

struct EventItem: Codable, Identifiable, Hashable {
    let id: Int
    let title: String
    let description: String
    let category: String
    let location: String
    let day: String
    let month: String
    let dateFormatted: String
    let timeFormatted: String
    let imageUrl: String?
}

struct Project: Codable, Identifiable, Hashable {
    let id: Int
    let title: String
    let description: String
    let status: String
    let progress: Int
    let location: String?
    let budget: String?
    let startDateFormatted: String?
    let endDateFormatted: String?
    let imageUrl: String?
}

// ─── /api/app/config ─────────────────────────────────────────────────────────

struct AppConfigDto: Codable {
    var settings: [String: String] = [:]
    var menu: [MenuItemDto] = []
    var categories: [CategoryDto] = []
    var pages: [PageSummary] = []
}

struct MenuItemDto: Codable, Identifiable, Hashable {
    var id: Int = 0
    var title: String
    var icon: String
    var color: String
    var bgColor: String
    var actionType: String      // screen, page, url, phone
    var actionValue: String
}

struct CategoryDto: Codable, Hashable {
    let type: String            // Place, Announcement, Event
    let name: String
    let icon: String
    let color: String
}

struct PageSummary: Codable, Identifiable, Hashable {
    let id: Int
    let title: String
    let slug: String
    let icon: String
    let summary: String?
}

struct ContentPage: Codable, Hashable {
    let id: Int
    let title: String
    let slug: String
    let icon: String
    let summary: String?
    let content: String
    let imageUrl: String?
}
