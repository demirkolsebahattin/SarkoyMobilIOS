import SwiftUI

/// Admin panelinden yönetilen ayarlar, menü, kategoriler ve sayfalar (/api/app/config).
@MainActor
final class AppConfig: ObservableObject {
    static let shared = AppConfig()

    @Published private(set) var data = AppConfigDto(menu: AppConfig.defaultMenu)

    func load() async {
        guard let dto = try? await Api.config() else { return }
        var d = dto
        if d.menu.isEmpty { d.menu = AppConfig.defaultMenu }
        data = d
    }

    // ─── Ayarlar ──────────────────────────────────────────────────────────────
    func s(_ key: String, _ def: String = "") -> String {
        let v = data.settings[key]?.trimmingCharacters(in: .whitespaces) ?? ""
        return v.isEmpty ? def : v
    }
    func b(_ key: String, _ def: Bool = true) -> Bool {
        guard let v = data.settings[key], !v.isEmpty else { return def }
        return v.lowercased() == "true"
    }
    func n(_ key: String, _ def: Int) -> Int { Int(data.settings[key] ?? "") ?? def }

    var primary: Color { Color(hex: data.settings["PrimaryColor"]) ?? Theme.sea }
    var header: Color { Color(hex: data.settings["HeaderColor"]) ?? Theme.deep }
    var background: Color { Color(hex: data.settings["BackgroundColor"]) ?? Theme.ground }

    // ─── Kategoriler ──────────────────────────────────────────────────────────
    func cats(_ type: String) -> [CategoryDto] { data.categories.filter { $0.type == type } }
    func cat(_ type: String, _ name: String) -> CategoryDto? {
        data.categories.first { $0.type == type && $0.name == name }
    }
    func catIcon(_ type: String, _ name: String, _ def: String = "ic:pin") -> String { cat(type, name)?.icon ?? def }
    func catColor(_ type: String, _ name: String, _ def: Color? = nil) -> Color {
        if let c = cat(type, name), let col = Color(hex: c.color) { return col }
        return def ?? primary
    }

    static let defaultMenu: [MenuItemDto] = [
        .init(id: 1, title: "Duyurular", icon: "ic:megaphone", color: "#0B2A3C", bgColor: "#E1EEF4", actionType: "screen", actionValue: "duyurular"),
        .init(id: 2, title: "Keşfet", icon: "ic:compass", color: "#0B2A3C", bgColor: "#E1EEF4", actionType: "screen", actionValue: "kesfet"),
        .init(id: 3, title: "Etkinlikler", icon: "ic:calendar", color: "#0B2A3C", bgColor: "#E1EEF4", actionType: "screen", actionValue: "etkinlikler"),
        .init(id: 4, title: "Vefat", icon: "ic:tulip", color: "#0B2A3C", bgColor: "#E1EEF4", actionType: "screen", actionValue: "vefat"),
        .init(id: 5, title: "Projeler", icon: "ic:hardhat", color: "#0B2A3C", bgColor: "#E1EEF4", actionType: "screen", actionValue: "projeler"),
        .init(id: 6, title: "Menü", icon: "ic:grid", color: "#0B2A3C", bgColor: "#E1EEF4", actionType: "screen", actionValue: "menu"),
    ]
}
