# Şarköy Belediyesi — iPhone (SwiftUI) Uygulaması

Android sürümüyle aynı: Sahil teması, üst slider, Şarköy Kart butonu, tüm ekranlar. Aynı API ve aynı admin panelini kullanır; admin panelindeki her değişiklik iki uygulamaya birden yansır.

> iPhone uygulaması **yalnızca Mac'teki Xcode ile derlenebilir** (Apple kuralı). Mac'iniz yoksa aşağıdaki bulut yollarını kullanın.

---

## Yol 1 — Mac olmadan, tarayıcıda test (ücretsiz başlangıç)

1. **GitHub'a yükleyin:** Bu klasörü (`SarkoyMobilIOS`) yeni bir GitHub deposunun köküne koyun ve gönderin.
2. **Derleme:** GitHub → depo → **Actions → "iOS Derleme" → Run workflow**.
   GitHub'ın Mac sunucusu projeyi derler (~10–15 dk). Bitince **Artifacts** altından `SarkoyMobil-Simulator.zip` indirin.
3. **Test:** [appetize.io](https://appetize.io) → ücretsiz hesap → **Upload** → zip'i yükleyin → iPhone tarayıcıda açılır.

**Önemli:** Appetize bulutta çalıştığı için API'nin **internetten erişilebilir** olması gerekir:
- API'yi sunucunuza (IIS/Plesk) yayınlayın, ya da geçici olarak bilgisayarınızdan açın:
  `cloudflared tunnel --url http://localhost:51326` (ücretsiz, size https://xxxx.trycloudflare.com adresi verir).
- GitHub → depo → **Settings → Secrets and variables → Actions → Variables** → `SARKOY_API_URL` = o adres. Sonra yeniden derleyin.

> Özel (private) depoda GitHub'ın aylık ücretsiz dakikası Mac için ~10 kat hızlı tükenir; açık (public) depoda sınırsızdır.

## Yol 2 — Gerçek iPhone'a kurmak (TestFlight)

1. **Apple Developer Program** üyeliği: yıllık 99 USD. Belediye adına açılacaksa kurum hesabı için **D-U-N-S numarası** gerekir (ücretsiz, birkaç gün sürer).
2. App Store Connect'te `tr.gov.sarkoybel.mobil` paket kimliğiyle uygulama oluşturun.
3. **[Codemagic](https://codemagic.io)** (ayda 500 dk ücretsiz) → GitHub deposunu bağlayın → Apple hesabını tanıtın → imzalı derleme + TestFlight'a otomatik yükleme.
4. iPhone'a App Store'dan **TestFlight** uygulamasını kurun → davet e-postasıyla uygulamayı yükleyin.

## Yol 3 — Mac bulunursa (en hızlı)

1. Mac'e Xcode (App Store, ücretsiz) ve `brew install xcodegen` kurun.
2. Klasörde: `xcodegen generate` → `SarkoyMobil.xcodeproj` açılır.
3. Üstten **iPhone simülatörü** seçin → ▶. Simülatörde API adresi `http://localhost:51326` olarak çalışır.
4. Kendi iPhone'unuz için: kabloyla bağlayın, **Signing & Capabilities → Team** kısmına ücretsiz Apple ID'nizi girin → ▶ (ücretsiz hesapla kurulum 7 gün geçerlidir).

Mac kiralamak da mümkün (MacinCloud vb. saatlik/aylık), ancak bu yolla sadece simülatörde test edilir.

---

## Ayarlar

| Ne | Nerede |
|---|---|
| API adresi | `project.yml` → `SARKOY_API_URL` (CI'da GitHub değişkeni) |
| Bildirimler | Firebase Console → iOS uygulaması ekle (`tr.gov.sarkoybel.mobil`) → `GoogleService-Info.plist` dosyasını `SarkoyMobil/` klasörüne koyun. APNs anahtarı için Developer hesabı gerekir. Dosya yoksa uygulama bildirimsiz çalışır. |
| Yayın | API'yi HTTPS'e alın, `project.yml` içindeki `NSAllowsArbitraryLoads` satırını kaldırın. |

## Yapı
```
SarkoyMobil/
├─ App/SarkoyApp.swift      giriş + bildirimler (Firebase, "sarkoybel" konusu)
├─ Data/                    Api, Models, AppConfig (admin ayarları)
├─ UI/                      Tema, ikonlar, ortak bileşenler, alt menü, yönlendirme
├─ Screens/                 Ana Sayfa, Keşfet, Yer Detay, Duyurular, Etkinlikler,
│                           Vefat, Projeler, İçerik Sayfası, Menü/İletişim
└─ Resources/               Outfit fontu, ikonlar, çizimler, logo (Assets.xcassets)
project.yml                 XcodeGen proje tanımı
.github/workflows/          Mac'siz derleme (GitHub Actions)
```
